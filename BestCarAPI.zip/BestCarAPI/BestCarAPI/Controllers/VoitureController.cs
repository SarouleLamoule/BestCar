﻿using BestCarAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BestCarAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VoitureController : ControllerBase
    { 

        [HttpGet(Name = "GetVoitures")]
        public List<Voiture> Get()
        {            
            return Voiture.voitureList;
        }




    }
}
