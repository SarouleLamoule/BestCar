﻿using BestCarAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BestCarAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarburantsVoitureController : ControllerBase
    {

       

        [HttpGet(Name = "GetCarburantsVoiture")]
        public List<String> Get()
        {
          
            List<String> carburants = new List<String>();
            foreach (Voiture voiture in Voiture.voitureList)
            {
                if (!carburants.Contains(voiture.Carburant))
                {
                    carburants.Add(voiture.Carburant);

                }
            }

            return carburants;
        }
    }
}
