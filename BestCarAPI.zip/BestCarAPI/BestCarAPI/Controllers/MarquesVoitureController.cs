﻿using BestCarAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BestCarAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MarquesVoitureController : ControllerBase
    {

       

        [HttpGet(Name = "GetMarquesVoiture")]
        public List<String> Get()
        {
            /*VoitureDAO voitureDAO= new VoitureDAO();
            voitureDAO.GetVoitures();*/
            List<String> marque = new List<String>();
            foreach (Voiture voiture in Voiture.voitureList)
            {
                if (!marque.Contains(voiture.Marque))
                {
                    marque.Add(voiture.Marque);

                }
            }

            return marque;
        }
    }
}
