﻿namespace BestCarAPI.Models
{
    public class Voiture
    {
        public String Marque { get; set; }
        public String Modele { get; set; }
        public String Carburant { get; set; }
        public int Puissance { get; set; }
        public String Boite { get; set; }
        public int NbPortes { get; set; }
        public int Capacité { get; set; }
        public String urlImage { get; set; }
        public static List<Voiture> voitureList { get; set; }

        public static void CreerVoiture()
        {
            voitureList = new List<Voiture>();
            Voiture voiture = new Voiture();
            voiture.Marque = "Nissan";
            voiture.Modele = "350Z";
            voiture.Carburant = "Essence";
            voiture.Puissance = 20;
            voiture.Boite = "Manuelle";
            voiture.NbPortes = 3;
            voiture.Capacité = 80;
            voiture.urlImage = "https://img4.autodeclics.com/photo_article/80362/11481/1200-L-la-plus-chere-des-nissan-350z-actuellement-en-vente.jpg";
            voitureList.Add(voiture);

            voiture = new Voiture();
            voiture.Marque = "Nissan";
            voiture.Modele = "370Z";
            voiture.Carburant = "Essence";
            voiture.Puissance = 25;
            voiture.Boite = "Manuelle";
            voiture.NbPortes = 3;
            voiture.Capacité = 72;
            voiture.urlImage = "https://cdn.motor1.com/images/mgl/67g7E/s1/nissan-370z-by-z1-motorsports.jpg";
            voitureList.Add(voiture);

            voiture = new Voiture();
            voiture.Marque = "Audi";
            voiture.Modele = "RS7";
            voiture.Carburant = "Essence";
            voiture.Puissance = 53;
            voiture.Boite = "Automatique";
            voiture.NbPortes = 5;
            voiture.Capacité = 73;
            voiture.urlImage = "https://cdn.drivek.it/configurator-covermobile/cars/fr/768/AUDI/RS-7-SPORTBACK/38956_HATCHBACK-5-DOORS/audi-rs-7-sportback-2019-mobile.jpg";
            voitureList.Add(voiture);

            voiture = new Voiture();
            voiture.Marque = "Audi";
            voiture.Modele = "S5";
            voiture.Carburant = "Diesel";
            voiture.Puissance = 22;
            voiture.Boite = "Automatique";
            voiture.NbPortes = 5;
            voiture.Capacité = 58;
            voiture.urlImage = "https://images.caradisiac.com/logos-ref/modele/modele--audi-s5-2e-generation/S7-modele--audi-s5-2e-generation.jpg";
            voitureList.Add(voiture);
        }

 

    }
}
